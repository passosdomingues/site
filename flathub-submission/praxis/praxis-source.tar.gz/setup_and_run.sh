#!/bin/bash
set -e

# SCRUM Master Application Setup Script
# Target: Linux Mint 22.2 (Ubuntu 24.04 base)

echo "[INFO] Starting automated setup for SCRUM Master..."

# 1. Install System Dependencies
echo "[INFO] Checking system dependencies..."
SUDO=""
if [ "$(id -u)" -ne 0 ]; then
    SUDO="sudo"
    echo "[INFO] We need sudo access to install build dependencies. Please enter your password if prompted."
fi

$SUDO apt-get update
$SUDO apt-get install -y curl git unzip xz-utils zip libglu1-mesa clang cmake ninja-build pkg-config libgtk-3-dev liblzma-dev libstdc++-12-dev

# 2. Install Flutter SDK if missing
FLUTTER_DIR="$HOME/.local/share/flutter"
if [ ! -d "$FLUTTER_DIR" ]; then
    echo "[INFO] Flutter SDK not found. Installing to $FLUTTER_DIR..."
    mkdir -p "$HOME/.local/share"
    git clone https://github.com/flutter/flutter.git -b stable "$FLUTTER_DIR"
    
    # Configure immediate path and disable analytics to avoid blocking
    export PATH="$FLUTTER_DIR/bin:$PATH"
    flutter config --no-analytics
else
    echo "[INFO] Flutter SDK found at $FLUTTER_DIR."
    export PATH="$FLUTTER_DIR/bin:$PATH"
    flutter config --no-analytics || true
fi

# 3. Configure Path
export PATH="$FLUTTER_DIR/bin:$PATH"

echo "[INFO] Verifying Flutter installation..."
flutter doctor --android-licenses || true # optimal, accept if possible or ignore
flutter doctor

# 4. Project Setup
PROJECT_DIR="$(pwd)"
echo "[INFO] Setting up project in $PROJECT_DIR..."

if [ ! -f "pubspec.yaml" ]; then
    echo "[ERROR] pubspec.yaml not found. Please run this script from the project root."
    exit 1
fi

# Hydrate Linux files if missing (Flutter create)
if [ ! -d "linux" ]; then
    echo "[INFO] Generating Linux platform files..."
    flutter create . --platforms=linux --org=com.antigravity
fi

# Install Project Dependencies
echo "[INFO] Getting packages..."
flutter pub get

# 5. Check Ollama
echo "[INFO] Checking AI Service (Ollama)..."
if ! command -v ollama &> /dev/null; then
    echo "[WARNING] Ollama is not installed. The AI features will not function."
    echo "[WARNING] Install it via 'curl -fsSL https://ollama.com/install.sh | sh' if you want AI."
else
    if ! pgrep -x "ollama" > /dev/null; then
        echo "[WARNING] Ollama is installed but not running. Starting it in background..."
        ollama serve &
        sleep 5
    fi
    # Check for model
    if ! ollama list | grep -q "deepseek-coder-v3:7b-q4"; then
        echo "[INFO] Pulling DeepSeek model (this may take a while)..."
        ollama pull deepseek-coder-v3:7b-q4
    fi
fi

# 6. Run Application
echo "[INFO] Building and Launching SCRUM Master..."
flutter run -d linux
