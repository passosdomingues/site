import 'package:drag_and_drop_lists/drag_and_drop_lists.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/task_card.dart';
import '../../services/app_provider.dart';
import '../../utils/constants.dart';
import 'task_card_widget.dart';

class ScrumBoard extends StatelessWidget {
  const ScrumBoard({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final cards = provider.cards;

    // Group cards by column
    final List<List<TaskCard>> columns = List.generate(4, (_) => []);
    for (var card in cards) {
      if (card.columnId >= 0 && card.columnId < 4) {
        columns[card.columnId].add(card);
      }
    }

    return DragAndDropLists(
      axis: Axis.horizontal,
      listWidth: 300,
      listDraggingWidth: 300,
      listPadding: const EdgeInsets.all(8.0),
      itemDragOnLongPress: false,
      itemDragHandle: const DragHandle(
        onLeft: true,
        child: Padding(
          padding: EdgeInsets.only(right: 10),
          child: Icon(Icons.drag_indicator, color: Colors.white30),
        ),
      ),
      children: List.generate(4, (index) {
        return DragAndDropList(
          header: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  AppConstants.columns[index].toUpperCase(),
                  style: TextStyle(
                    fontWeight: FontWeight.bold, 
                    letterSpacing: 1.0, 
                    fontSize: 13,
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.8),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${columns[index].length}',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          children: columns[index].map((card) {
            return DragAndDropItem(
              child: TaskCardWidget(
                card: card,
                onTap: () {
                  _showEditCardDialog(context, card);
                },
              ),
            );
          }).toList(),
          footer: _buildFooter(context, index),
        );
      }),
      onItemReorder: (int oldItemIndex, int oldListIndex, int newItemIndex, int newListIndex) {
        final card = columns[oldListIndex][oldItemIndex];
        provider.updateCardStatus(card, newListIndex);
      },
      onListReorder: (int oldListIndex, int newListIndex) {
        // Columns are fixed, do not allow reordering lists
      },
      listDecoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor, 
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
    );
  }

  Widget _buildFooter(BuildContext context, int columnIndex) {
    if (columnIndex == 0 || columnIndex == 1) { // Only add to Backlog or To Do
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: OutlinedButton.icon(
          onPressed: () => _showAddCardDialog(context, columnIndex),
          icon: const Icon(Icons.add, size: 16),
          label: const Text("Add Card"),
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.white54,
            side: const BorderSide(color: Colors.white10),
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
      );
    }
    return const SizedBox(height: 16);
  }

  void _showAddCardDialog(BuildContext context, int columnIndex) {
    final titleController = TextEditingController();
    final descController = TextEditingController();
    int points = 1;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("New Task"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleController, decoration: const InputDecoration(labelText: "Title")),
            TextField(controller: descController, decoration: const InputDecoration(labelText: "Description")),
            DropdownButtonFormField<int>(
              value: points,
              items: [1, 2, 3, 5, 8, 13].map((p) => DropdownMenuItem(value: p, child: Text("$p Points"))).toList(),
              onChanged: (val) => points = val!,
              decoration: const InputDecoration(labelText: "Story Points"),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () {
              Provider.of<AppProvider>(context, listen: false)
                  .addTask(titleController.text, descController.text, points, columnIndex);
              Navigator.pop(ctx);
            },
            child: const Text("Add"),
          ),
        ],
      ),
    );
  }

  void _showEditCardDialog(BuildContext context, TaskCard card) {
    // Implement edit/delete dialog
    // Keep it minimal for now
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(card.title),
        content: Text(card.description.isNotEmpty ? card.description : "No description."),
        actions: [
          TextButton(
            onPressed: () {
               Provider.of<AppProvider>(context, listen: false).deleteCard(card.id!);
               Navigator.pop(ctx);
            },
            child: const Text("Delete", style: TextStyle(color: Colors.red)),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Close")),
        ],
      ),
    );
  }
}
