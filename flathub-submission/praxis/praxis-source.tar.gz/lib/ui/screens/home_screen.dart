import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/app_provider.dart';
import '../../models/task_card.dart'; // Ensure this import exists
import '../widgets/burndown_chart.dart';
import '../widgets/scrum_board.dart';
import '../../utils/constants.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _showBurndown = false;
  bool _showAIChat = false; // Default closed
  bool _isSM = false; // Role toggle
  final TextEditingController _chatController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppProvider>(context, listen: false).checkAiStatus();
    });
  }

  // Temporary stubs for export/import until Provider is updated
  void _handleExport(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Export functionality requires file access permission setup.")),
    );
  }

  void _handleImport(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Import functionality requires file access permission setup.")),
    );
  }
  
  void _showAddSprintDialog(BuildContext context) {
      final nameCtrl = TextEditingController();
      final start = DateTime.now();
      final end = DateTime.now().add(const Duration(days: 14));
      
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text("New Sprint"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
               TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: "Sprint Name")),
               const SizedBox(height: 16),
               const Text("Duration: 14 Days (Default)"),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
             ElevatedButton(
              onPressed: () {
                if (nameCtrl.text.isNotEmpty) {
                    Provider.of<AppProvider>(context, listen: false).addSprint(nameCtrl.text, start, end);
                }
                Navigator.pop(ctx);
              },
              child: const Text("Create"),
            ),
          ],
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final theme = Theme.of(context);

    return Scaffold(
      body: Row(
        children: [
          // Left Sidebar (Navigation Rail)
          NavigationRail(
            backgroundColor: theme.scaffoldBackgroundColor, // Match background for seamless look or use surface
            selectedIndex: _showBurndown ? 1 : 0,
            onDestinationSelected: (int index) {
              setState(() {
                _showBurndown = index == 1;
              });
            },
            labelType: NavigationRailLabelType.all,
            leading: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24.0),
              child: Column(
                children: [
                  Text(
                    'prAxIs',
                    style: theme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.5,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'where work becomes action',
                    style: theme.textTheme.labelSmall?.copyWith(
                      fontSize: 8,
                      color: Colors.white38,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            destinations: const [
              NavigationRailDestination(
                icon: Icon(Icons.view_kanban),
                label: Text('Board'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.bar_chart),
                label: Text('Stats'),
              ),
            ],
            trailing: Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // Role Toggle
                  IconButton(
                    icon: Icon(_isSM ? Icons.add_moderator : Icons.person_outline),
                    tooltip: 'Role: ${_isSM ? "prAxIs Master" : "Product Owner"}',
                    color: _isSM ? theme.colorScheme.secondary : theme.colorScheme.tertiary,
                    onPressed: () => setState(() => _isSM = !_isSM),
                  ),
                  const SizedBox(height: 10),
                  // Export/Import
                  IconButton(
                    icon: const Icon(Icons.download),
                    tooltip: 'Export',
                    onPressed: () => _handleExport(context),
                  ),
                  IconButton(
                    icon: const Icon(Icons.upload),
                    tooltip: 'Import',
                    onPressed: () => _handleImport(context),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
          const VerticalDivider(width: 1, thickness: 1, color: Colors.white10),
          
          // Main Content Area
          Expanded(
            child: Column(
              children: [
                // Top Header Bar
                Container(
                  height: 64,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  color: theme.scaffoldBackgroundColor, 
                  child: Row(
                    children: [
                      // Active Sprint Info
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            provider.activeSprint?.name ?? "No Active Sprint",
                            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          if (provider.activeSprint != null)
                             Text(
                              provider.activeSprint!.formattedRange,
                              style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey),
                            ),
                        ],
                      ),
                      
                      const Spacer(),
                      
                      // Progress Bar (if active sprint)
                      if (provider.activeSprint != null) ...[
                        SizedBox(
                          width: 150,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                               Text("Sprint Progress", style: TextStyle(fontSize: 10, color: Colors.grey)),
                               const SizedBox(height: 4),
                               ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: provider.activeSprint!.progress, 
                                  minHeight: 6,
                                  backgroundColor: Colors.white10,
                                  valueColor: AlwaysStoppedAnimation(theme.colorScheme.primary),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 24),
                      ],

                      // Top Actions
                      FilledButton.icon(
                        icon: const Icon(Icons.add),
                        label: const Text("New Sprint"),
                        style: FilledButton.styleFrom(backgroundColor: Colors.white10, foregroundColor: Colors.white),
                         onPressed: () => _showAddSprintDialog(context),
                      ),
                      const SizedBox(width: 12),
                      
                      IconButton(
                        icon: Icon(Icons.smart_toy, color: _showAIChat ? theme.colorScheme.primary : Colors.grey),
                        tooltip: "Toggle AI Assistant",
                        onPressed: () => setState(() => _showAIChat = !_showAIChat),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, thickness: 1, color: Colors.white10),

                // Main View (Board or Stats)
                Expanded(
                  child: provider.isLoading 
                    ? const Center(child: CircularProgressIndicator())
                    : _showBurndown 
                        ? const Padding(padding: EdgeInsets.all(24), child: BurndownChart())
                        : const Padding(padding: EdgeInsets.all(0), child: ScrumBoard()),
                ),
              ],
            ),
          ),

          // Right Sidebar (AI Chat)
          if (_showAIChat) ...[
             const VerticalDivider(width: 1, thickness: 1, color: Colors.white10),
             Container(
               width: 320,
               color: theme.scaffoldBackgroundColor,
               child: Column(
                 children: [
                   // Chat Header
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        border: Border(bottom: BorderSide(color: Colors.white10)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.auto_awesome, size: 18, color: theme.colorScheme.secondary),
                          const SizedBox(width: 8),
                          Text(
                            _isSM ? "AI prAxIs Master" : "AI Product Owner",
                            style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onSurface),
                          ),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.history, size: 18),
                            tooltip: "Undo last change",
                            onPressed: () => provider.undo(),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, size: 18),
                            onPressed: () => setState(() => _showAIChat = false),
                            visualDensity: VisualDensity.compact,
                          ),
                        ],
                      ),
                    ),
                    // Governance Controls
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: const BoxDecoration(
                        border: Border(bottom: BorderSide(color: Colors.white10)),
                      ),
                      child: Row(
                        children: [
                          Text("AI Autonomy", style: theme.textTheme.labelSmall),
                          const Spacer(),
                          Switch.adaptive(
                            value: provider.isAutoApplyEnabled,
                            onChanged: (_) => provider.toggleAutoApply(),
                            activeColor: theme.colorScheme.primary,
                          ),
                        ],
                      ),
                    ),
                   // Chat Messages
                   Expanded(
                     child: ListView(
                       padding: const EdgeInsets.all(16),
                       children: [
                         if (!provider.ollamaRunning)
                            _buildAiStatusPlaceholder(
                              context, 
                              "Ollama not detected", 
                              "Make sure Ollama is running on your system. Visit [ollama.com](https://ollama.com) to download.",
                              Icons.error_outline,
                            )
                         else if (!provider.modelAvailable)
                            _buildAiStatusPlaceholder(
                              context, 
                              "Model missing", 
                              "Please run 'ollama pull deepseek-coder-v3:7b-q4' in your terminal.",
                              Icons.download_for_offline_outlined,
                            ),
                         if (provider.isAiThinking)
                           const Padding(
                             padding: EdgeInsets.only(bottom: 16),
                             child: LinearProgressIndicator(),
                           ),
                         
                         // Pending AI Actions
                         if (provider.pendingActions.isNotEmpty)
                           Container(
                              margin: const EdgeInsets.only(bottom: 16),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: theme.colorScheme.primaryContainer.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: theme.colorScheme.primary.withOpacity(0.3)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.pending_actions, size: 16, color: theme.colorScheme.primary),
                                      const SizedBox(width: 8),
                                      const Text("Proposed Actions", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  ...provider.pendingActions.map((action) => Padding(
                                    padding: const EdgeInsets.only(bottom: 4),
                                    child: Text(
                                      "• ${action['type']}: ${action['data']['title'] ?? action['data']['card_id'] ?? ''}",
                                      style: const TextStyle(fontSize: 11),
                                    ),
                                  )),
                                  const SizedBox(height: 12),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      TextButton(
                                        onPressed: () => provider.rejectActions(),
                                        child: const Text("Reject", style: TextStyle(color: Colors.redAccent, fontSize: 12)),
                                      ),
                                      const SizedBox(width: 8),
                                      ElevatedButton(
                                        onPressed: () => provider.acceptActions(),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: theme.colorScheme.primary,
                                          foregroundColor: Colors.white,
                                          visualDensity: VisualDensity.compact,
                                        ),
                                        child: const Text("Accept", style: TextStyle(fontSize: 12)),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                           ),
                         
                         if (provider.aiMessage.isNotEmpty)
                           Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white10,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: SelectableText(provider.aiMessage),
                           )
                         else if (provider.ollamaRunning && provider.modelAvailable)
                           Column(
                             mainAxisAlignment: MainAxisAlignment.center,
                             children: [
                               const SizedBox(height: 40),
                               Icon(Icons.help_outline, size: 48, color: Colors.white10),
                               const SizedBox(height: 16),
                               Text(
                                 "Ask me anything about your sprint process, backlog, or agile best practices.",
                                 textAlign: TextAlign.center,
                                 style: TextStyle(color: Colors.white38),
                               ),
                             ],
                           ),
                       ],
                     ),
                   ),
                   // Quick Actions
                   Padding(
                     padding: const EdgeInsets.symmetric(horizontal: 16),
                     child: Wrap(
                       spacing: 8,
                       runSpacing: 8,
                       children: [
                         ActionChip(
                           label: const Text("Analyze Sprint"),
                           onPressed: () => provider.askAI("Analyze the current sprint progress and suggest improvements.", isSM: true),
                           backgroundColor: Colors.white10,
                           side: BorderSide.none,
                         ),
                         ActionChip(
                           label: const Text("Refine Backlog"),
                           onPressed: () => provider.askAI("Review the backlog and suggest priorities.", isSM: false),
                           backgroundColor: Colors.white10,
                            side: BorderSide.none,
                         ),
                       ],
                     ),
                   ),
                   // Input Area
                   Padding(
                     padding: const EdgeInsets.all(16.0),
                     child: TextField(
                       controller: _chatController,
                       enabled: provider.ollamaRunning && provider.modelAvailable,
                       decoration: InputDecoration(
                         hintText: "Type a message...",
                         filled: true,
                         fillColor: Colors.black26, 
                         border: OutlineInputBorder(
                           borderRadius: BorderRadius.circular(24),
                           borderSide: BorderSide.none,
                         ),
                         contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                         suffixIcon: IconButton(
                           icon: const Icon(Icons.send, size: 18),
                           onPressed: (provider.ollamaRunning && provider.modelAvailable) 
                             ? () {
                                if (_chatController.text.trim().isNotEmpty) {
                                  provider.askAI(_chatController.text, isSM: _isSM);
                                  _chatController.clear();
                                }
                             } : null,
                         ),
                       ),
                       onSubmitted: (val) {
                         if (val.trim().isNotEmpty && provider.ollamaRunning && provider.modelAvailable) {
                            provider.askAI(val, isSM: _isSM);
                            _chatController.clear();
                          }
                       },
                     ),
                   ),
                 ],
               ),
             ),
          ],
        ],
      ),
    );
  }

  Widget _buildAiStatusPlaceholder(BuildContext context, String title, String subtitle, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 32, color: Colors.orangeAccent.withOpacity(0.8)),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(
            subtitle, 
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: Colors.white54),
          ),
        ],
      ),
    );
  }
}
