import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import '../models/sprint.dart';
import '../models/task_card.dart';
import 'database_helper.dart';
import 'ollama_service.dart';
import 'export_import_service.dart';

class AppProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;
  final OllamaService _ollama = OllamaService();
  final ExportImportService _exportImport = ExportImportService();

  List<Sprint> sprints = [];
  Sprint? activeSprint;
  List<TaskCard> cards = [];
  bool isLoading = false;
  String aiMessage = '';
  bool isAiThinking = false;
  bool ollamaRunning = false;
  bool modelAvailable = false;
  
  // History for Snapshots
  final List<List<TaskCard>> _history = [];
  bool isAutoApplyEnabled = false;
  List<Map<String, dynamic>> pendingActions = [];

  Future<void> checkAiStatus() async {
    ollamaRunning = await _ollama.isOllamaRunning();
    if (ollamaRunning) {
      modelAvailable = await _ollama.isModelAvailable();
    } else {
      modelAvailable = false;
    }
    notifyListeners();
  }

  Future<void> loadData() async {
    isLoading = true;
    notifyListeners();
    
    try {
      // Ensure DB is open
      final db = await _db.database; 
      // Re-init logic is inside getter, so just accessing it ensures it's open.
      
      sprints = await _db.getAllSprints();
      activeSprint = await _db.getActiveSprint();
      
      if (activeSprint != null) {
        cards = await _db.getCardsBySprint(activeSprint!.id!);
      } else {
        cards = [];
      }
    } catch (e) {
      debugPrint("Error loading data: $e");
      // Could set an error state here
    }

    isLoading = false;
    notifyListeners();
  }

  void createSnapshot() {
    _history.add(cards.map((c) => c.copyWith()).toList());
    if (_history.length > 20) _history.removeAt(0); // Cap history
  }

  void undo() {
    if (_history.isNotEmpty) {
      cards = _history.removeLast();
      // Persistence: Sync all cards back to DB (simple sync for undo)
      for (var card in cards) {
        _db.updateCard(card);
      }
      notifyListeners();
    }
  }

  String getBoardStateJson() {
    final state = {
      'active_sprint': activeSprint?.name ?? 'None',
      'columns': [
        {'id': 0, 'name': 'Backlog'},
        {'id': 1, 'name': 'To Do'},
        {'id': 2, 'name': 'In Progress'},
        {'id': 3, 'name': 'Done'},
      ],
      'cards': cards.map((c) => {
        'id': c.id,
        'title': c.title,
        'column': c.columnId,
        'points': c.points,
      }).toList(),
    };
    return jsonEncode(state);
  }

  Future<void> executeAiActions(List<dynamic> actions) async {
    createSnapshot();
    
    for (var action in actions) {
      final type = action['type'];
      final data = action['data'];

      try {
        if (type == 'MOVE') {
          final cardId = data['card_id'];
          final newCol = data['new_column'];
          final card = cards.firstWhere((c) => c.id == cardId);
          await updateCardStatus(card, newCol);
        } else if (type == 'CREATE') {
          await addTask(data['title'], data['description'] ?? '', data['points'] ?? 1, data['column'] ?? 0);
        } else if (type == 'EDIT') {
          final cardId = data['card_id'];
          final card = cards.firstWhere((c) => c.id == cardId);
          final updated = card.copyWith(
            title: data['title'] ?? card.title,
            description: data['description'] ?? card.description,
            points: data['points'] ?? card.points,
          );
          await _db.updateCard(updated);
        }
      } catch (e) {
        debugPrint("AI Action failed: $e");
      }
    }
    await loadData();
  }
  
  Future<void> addSprint(String name, DateTime start, DateTime end) async {
    try {
      final sprint = Sprint(name: name, startDate: start, endDate: end, isActive: true);
      await _db.createSprint(sprint);
      await loadData();
    } catch(e) {
      debugPrint("Error adding sprint: $e");
    }
  }

  Future<void> addTask(String title, String description, int points, int subColumn) async {
    if (activeSprint == null) return;
    
    try {
      final card = TaskCard(
        sprintId: activeSprint!.id!,
        columnId: subColumn, 
        title: title, 
        description: description,
        labelColorIndex: 0, 
        points: points
      );
      await _db.createCard(card);
      await loadData();
    } catch(e) {
       debugPrint("Error adding task: $e");
    }
  }
  
  // Optimistic update wrapper
  Future<void> updateCardStatus(TaskCard card, int newColumnId) async {
    final oldColumn = card.columnId;
    
    // Update local state immediately
    final cardIndex = cards.indexWhere((c) => c.id == card.id);
    if (cardIndex != -1) {
      cards[cardIndex].columnId = newColumnId;
      notifyListeners();
    }

    try {
      final updated = card.copyWith(columnId: newColumnId);
      await _db.updateCard(updated);
    } catch (e) {
      // Revert on failure
      if (cardIndex != -1) {
        cards[cardIndex].columnId = oldColumn;
        notifyListeners();
      }
      debugPrint("Error moving card: $e");
    }
  }

  Future<void> deleteCard(int id) async {
    try {
      await _db.deleteCard(id);
      cards.removeWhere((c) => c.id == id);
      notifyListeners();
    } catch(e) {
      debugPrint("Error deleting card: $e");
    }
  }
  
  Future<void> askAI(String prompt, {bool isSM = false}) async {
    isAiThinking = true;
    notifyListeners();
    
    try {
      final systemPrompt = isSM 
        ? "You are a Scrum Master. Help the team remove impediments and improve process. Keep answers concise."
        : "You are a Product Owner. Prioritize the backlog and clarify requirements. Keep answers concise.";
        
      final response = await _ollama.generateResponse(
        prompt, 
        systemPrompt: systemPrompt,
        contextJson: getBoardStateJson(),
      );
      
      // Parse for actions if present
      _parseAiActions(response);
      
      aiMessage = response.replaceAll(RegExp(r'```json[\s\S]*?```'), '').trim();
    } catch (e) {
      aiMessage = "Error: $e";
    } finally {
      isAiThinking = false;
      notifyListeners();
    }
  }

  void _parseAiActions(String response) {
    final regex = RegExp(r'```json([\s\S]*?)```');
    final matches = regex.allMatches(response);
    
    pendingActions = [];
    for (var match in matches) {
      try {
        final jsonStr = match.group(1)?.trim() ?? '';
        final dynamic decoded = jsonDecode(jsonStr);
        if (decoded is List) {
          pendingActions.addAll(decoded.cast<Map<String, dynamic>>());
        } else if (decoded is Map) {
          pendingActions.add(decoded.cast<String, dynamic>());
        }
      } catch (e) {
        debugPrint("Failed to parse AI action JSON: $e");
      }
    }

    if (isAutoApplyEnabled && pendingActions.isNotEmpty) {
      executeAiActions(pendingActions);
      pendingActions = [];
    }
  }

  void acceptActions() {
    executeAiActions(pendingActions);
    pendingActions = [];
    notifyListeners();
  }

  void rejectActions() {
    pendingActions = [];
    notifyListeners();
  }

  void toggleAutoApply() {
    isAutoApplyEnabled = !isAutoApplyEnabled;
    notifyListeners();
  }
  
  Future<List<String>> suggestTasks(String goal) async {
    try {
      final prompt = "Generate 3 agile user stories (titles only) for a feature: $goal. Return ONLY a JSON array of strings, no markdown.";
      final response = await _ollama.generateResponse(prompt);
      
      // Clean cleanup markdown code blocks if present
      final cleanResponse = response.replaceAll('```json', '').replaceAll('```', '').trim();

      try {
        final List<dynamic> list = jsonDecode(cleanResponse);
        return list.map((e) => e.toString()).toList();
      } catch (e) {
        // Fallback: split by newlines if JSON fails
        return response.split('\n')
            .where((l) => l.trim().isNotEmpty && !l.startsWith('Error'))
            .take(3)
            .map((l) => l.replaceAll(RegExp(r'^[-*0-9.]+ '), '').trim()) // Remove bullet points
            .toList();
      }
    } catch (e) {
      return ["Error generating tasks. Check Ollama."];
    }
  }

  Future<void> clearAiMessage() async {
    aiMessage = '';
    notifyListeners();
  }

  Future<File> exportData() async {
    return await _exportImport.exportData();
  }

  Future<void> importData(File file) async {
    await _exportImport.importData(file);
    await loadData();
  }
}
