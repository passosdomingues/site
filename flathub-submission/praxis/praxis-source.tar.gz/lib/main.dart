import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
// import 'package:window_size/window_size.dart' as window_size; // Removed to fix build
import 'services/app_provider.dart';
import 'ui/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  if (Platform.isLinux || Platform.isWindows) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    /*
    // Optional: Window size constraint
    // window_size.setWindowTitle('prAxIs');
    window_size.setWindowMinSize(const Size(800, 600));
    window_size.setWindowMaxSize(const Size(1920, 1080));
    */
  }

  runApp(const ScrumMasterApp());
}

class ScrumMasterApp extends StatelessWidget {
  const ScrumMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()..loadData()),
      ],
      child: MaterialApp(
        title: 'prAxIs',
        debugShowCheckedModeBanner: false,
        theme: _buildTheme(),
        home: const HomeScreen(),
      ),
    );
  }

  ThemeData _buildTheme() {
    // COSMIC / Pop!_OS inspired palette
    const bgBase = Color(0xFF262626); // Cosmic Dark Grey
    const bgSurface = Color(0xFF333333); // Slightly lighter for cards
    const accentColor = Color(0xFF48B9C7); // Pop!_OS Cyan
    const secondaryAccent = Color(0xFFEDA55C); // Pop!_OS Orange
    const textPrimary = Color(0xFFF2F2F2);
    
    final base = ThemeData.dark();
    return base.copyWith(
      scaffoldBackgroundColor: bgBase,
      colorScheme: const ColorScheme.dark(
        primary: accentColor,
        secondary: secondaryAccent,
        surface: bgSurface,
        background: bgBase,
        onSurface: textPrimary,
      ),
      cardTheme: CardThemeData(
        color: bgSurface,
        elevation: 0, // Flat design
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: Colors.white.withOpacity(0.08), width: 1),
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: bgBase,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: textPrimary,
          fontFamily: 'Fira Sans', // Attempt to use system font if available
        ),
      ),
      // Buttons
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentColor,
          foregroundColor: Colors.black,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: secondaryAccent,
        foregroundColor: Colors.white,
      ),
    );
  }
}
