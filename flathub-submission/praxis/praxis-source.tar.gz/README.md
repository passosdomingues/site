# SCRUM Master

A high-performance, offline-first SCRUM manager for Linux Desktop.

## Features
- **100% Offline**: No cloud, no tracking.
- **AI-Powered**: Integrates with local Ollama (DeepSeek V3) for PO/SM assistance.
- **Performance**: 60fps drag & drop, instant load.
- **Privacy**: Local SQLite database + JSON Export/Import.

## Prerequisites

1.  **Flutter SDK**: Installed and on your PATH.
2.  **Ollama**: Installed locally.
    ```bash
    ollama serve
    ollama pull deepseek-coder-v3:7b-q4
    ```

## Setup

Since the project structure was generated manually:

1.  **Hydrate Flutter Project**:
    ```bash
    cd scrum_master
    flutter create . --platforms=linux --org=com.antigravity
    ```

2.  **Install Dependencies**:
    ```bash
    flutter pub get
    ```

## Build & Run

### Debug
```bash
flutter run -d linux
```

### Release
```bash
flutter build linux
```

### Flatpak
```bash
flatpak-builder --repo=repo --force build com.antigravity.scrum_master.yml
flatpak build-bundle repo scrum_master.flatpak com.antigravity.scrum_master
flatpak install scrum_master.flatpak
```
