#!/bin/bash

# ==============================================================================
# SCRIPT DE AUTOMACAO DE SUBMISSAO FLATHUB - V13 (GENERALIZADO)
# ==============================================================================

set -e

# --- 1. CONFIGURACOES DO PROJETO ---
# Nome da pasta do projeto dentro do repositorio de submissao
PROJECT_SLUG="praxis"
# ID final do aplicativo no Flathub
APP_ID="io.github.passosdomingues.${PROJECT_SLUG}"
# Versao do Runtime do GNOME/Freedesktop
RUNTIME_VERSION="24.08"
# Diretorio onde esta o codigo fonte AGORA (Pasta atual)
SOURCE_DIR=$(pwd)
# Diretorio do repositorio 'site' (Destino)
SITE_REPO_DIR="$HOME/github/site"

# --- DEFINICOES AUTOMATICAS ---
SUBMISSION_ROOT="flathub-submission"
# Caminho final: ~/github/site/flathub-submission/praxis
PROJECT_DEST_DIR="$SITE_REPO_DIR/$SUBMISSION_ROOT/$PROJECT_SLUG"
ARCHIVE_FILENAME="${PROJECT_SLUG}-source.tar.gz"
MANIFEST_FILENAME="${APP_ID}.yml"

# --- FUNCAO DE LOG ---
log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

log "------------------------------------------------------------------------"
log "INICIANDO EMPACOTAMENTO FLATHUB (V13)"
log "Origem: $SOURCE_DIR"
log "Destino: $PROJECT_DEST_DIR"
log "------------------------------------------------------------------------"

# --- 2. VERIFICACOES PRELIMINARES ---

if [ ! -d "$SITE_REPO_DIR" ]; then
    log "ERRO FATAL: O diretorio do repositorio site ($SITE_REPO_DIR) nao foi encontrado."
    exit 1
fi

if [ ! -f "$SOURCE_DIR/flatpak/com.antigravity.scrum_master.yml" ] && [ ! -f "$SOURCE_DIR/$MANIFEST_FILENAME" ]; then
    # Tenta achar qualquer yml se o nome exato nao existir
    if [ -z "$(find "$SOURCE_DIR" -maxdepth 1 -name '*.yml')" ]; then
        log "ERRO FATAL: Nenhum arquivo de manifesto (.yml) encontrado na origem."
        exit 1
    fi
fi

# --- 3. PREPARACAO DO AMBIENTE DE DESTINO ---

log "Preparando diretorios de destino..."
# Garante que a pasta do projeto existe dentro do repositorio site
mkdir -p "$PROJECT_DEST_DIR"

# Limpa versoes anteriores do pacote para evitar sujeira
rm -f "$PROJECT_DEST_DIR/$ARCHIVE_FILENAME"

# Descobre a URL RAW baseada na branch atual do repositorio site
cd "$SITE_REPO_DIR"
CURRENT_BRANCH=$(git branch --show-current)
[ -z "$CURRENT_BRANCH" ] && CURRENT_BRANCH="main"

# Constroi a URL publica onde o arquivo estara disponivel
REPO_URL_BASE=$(git remote get-url origin | sed 's/git@github.com:/https:\/\/github.com\//' | sed 's/\.git$//')
RAW_FILE_URL="https://raw.githubusercontent.com/passosdomingues/site/$CURRENT_BRANCH/$SUBMISSION_ROOT/$PROJECT_SLUG/$ARCHIVE_FILENAME"

log "Branch detectada: $CURRENT_BRANCH"
log "URL de download futura: $RAW_FILE_URL"

# --- 4. EMPACOTAMENTO DO CODIGO FONTE (TARBALL) ---

log "Compactando codigo fonte (excluindo binarios e modelos de IA)..."
cd "$SOURCE_DIR"

# Cria o tar.gz excluindo arquivos pesados e desnecessarios
tar -czf "$PROJECT_DEST_DIR/$ARCHIVE_FILENAME" \
    --exclude='.git' \
    --exclude='.gitignore' \
    --exclude='build' \
    --exclude='build-dir' \
    --exclude='.flatpak-builder' \
    --exclude='*.flatpak' \
    --exclude='*ollama*' \
    --exclude='*.tar' \
    --exclude='*.tar.gz' \
    --exclude='*.zst' \
    --exclude='bin/*' \
    .

# Verifica o tamanho do arquivo
cd "$PROJECT_DEST_DIR"
FILE_SIZE_MB=$(du -m "$ARCHIVE_FILENAME" | cut -f1)
log "Tamanho do pacote: ${FILE_SIZE_MB} MB"

if [ "$FILE_SIZE_MB" -gt 95 ]; then
    log "ERRO: O arquivo gerado e maior que 95MB. O GitHub rejeitara."
    exit 1
fi

# Calcula o Hash SHA256
SHA256=$(sha256sum "$ARCHIVE_FILENAME" | awk '{print $1}')
log "SHA256 calculado: $SHA256"

# --- 5. PROCESSAMENTO DO MANIFESTO E ASSETS ---

log "Processando manifesto e arquivos de suporte..."

# Copia e renomeia o manifesto original
cd "$SOURCE_DIR"
ORIGINAL_MANIFEST=$(find . -maxdepth 1 -name "*.yml" | head -n 1)
cp "$ORIGINAL_MANIFEST" "$PROJECT_DEST_DIR/$MANIFEST_FILENAME"

# Copia Icone, Desktop e Appdata se existirem
find . -name "*.png" -print0 | xargs -0 -I {} cp {} "$PROJECT_DEST_DIR/$APP_ID.png" 2>/dev/null || true
find . -name "*.desktop" -print0 | xargs -0 -I {} cp {} "$PROJECT_DEST_DIR/$APP_ID.desktop" 2>/dev/null || true
find . -name "*.metainfo.xml" -o -name "*.appdata.xml" -print0 | xargs -0 -I {} cp {} "$PROJECT_DEST_DIR/$APP_ID.metainfo.xml" 2>/dev/null || true

# --- 6. EDICAO DO MANIFESTO (YAML PATCHING) ---

cd "$PROJECT_DEST_DIR"
log "Aplicando alteracoes no manifesto YAML..."

OLD_ID_RAW=$(basename "$ORIGINAL_MANIFEST" .yml)

# Substituicoes globais de ID e Versao
sed -i "s/$OLD_ID_RAW/$APP_ID/g" "$MANIFEST_FILENAME"
sed -i "s/runtime-version: .*/runtime-version: '$RUNTIME_VERSION'/g" "$MANIFEST_FILENAME"

# Atualizacao de referencias nos arquivos auxiliares
sed -i "s/^Icon=.*/Icon=$APP_ID/" "$APP_ID.desktop" 2>/dev/null || true
sed -i "s/$OLD_ID_RAW/$APP_ID/g" "$APP_ID.desktop" 2>/dev/null || true
sed -i "s/$OLD_ID_RAW/$APP_ID/g" "$APP_ID.metainfo.xml" 2>/dev/null || true

# Ajustes de Permissao (Padronizacao)
sed -i "s/--filesystem=home/--filesystem=xdg-documents/g" "$MANIFEST_FILENAME"
sed -i "s/--filesystem=host//g" "$MANIFEST_FILENAME"

# Garante IPC (Inter-Process Communication) para X11/Wayland
if ! grep -q -- "--share=ipc" "$MANIFEST_FILENAME"; then
    sed -i "/finish-args:/a \ \ - --share=ipc" "$MANIFEST_FILENAME"
fi

# --- SUBSTITUICAO DA FONTE (SOURCE) ---
# Remove definicoes antigas de 'dir', 'git', 'path', etc.
sed -i "/type: dir/d" "$MANIFEST_FILENAME"
sed -i "/type: git/d" "$MANIFEST_FILENAME"
sed -i "/path: \./d" "$MANIFEST_FILENAME"
sed -i "/url: /d" "$MANIFEST_FILENAME"
sed -i "/branch: /d" "$MANIFEST_FILENAME"
sed -i "/commit: /d" "$MANIFEST_FILENAME"

# Injeta a nova definicao de 'archive'
# Usa o pipe | como delimitador e insere com indentacao de 4 espacos
sed -i "s|^\(\s*\)sources:|\1sources:\n\1  - type: archive\n\1    url: $RAW_FILE_URL\n\1    sha256: $SHA256|" "$MANIFEST_FILENAME"

log "Manifesto atualizado com sucesso."

# --- 7. SINCRONIZACAO COM O GITHUB (SITE) ---

log "Enviando arquivos para o repositorio de hospedagem..."
cd "$SITE_REPO_DIR"

git add .

if git diff-index --quiet HEAD --; then
    log "Nenhuma alteracao detectada no repositorio."
else
    git commit -m "Update Flathub Submission: $PROJECT_SLUG ($SHA256)"
    git push --set-upstream origin "$CURRENT_BRANCH"
    log "Upload concluido. Arquivos estao online."
fi

# --- 8. VALIDACAO FINAL (LINTER) ---

log "Executando validacao local (Linter)..."
cd "$PROJECT_DEST_DIR"

# Executa o linter e captura a saida
flatpak run --command=flatpak-builder-lint org.flatpak.Builder manifest "$MANIFEST_FILENAME" > linter_report.txt 2>&1 || true

cat linter_report.txt

log "------------------------------------------------------------------------"
log "PROCESSO FINALIZADO"
log "1. Codigo fonte hospedado em: $RAW_FILE_URL"
log "2. Pasta de submissao pronta em: $PROJECT_DEST_DIR"
log "3. Proximo passo: Verificar o linter_report.txt e criar o PR no Flathub."
log "------------------------------------------------------------------------"
