#!/bin/bash
set -e

APP_ID="io.github.passosdomingues.praxis"
FLATPAK_DIR="flatpak"
BUILD_DIR="build_flatpak"

echo "Starting prAxIs Flatpak packaging..."

# 1. Ensure Flutter is built in release mode
echo "Building Flutter Linux app..."
export PATH=$PWD/local_toolchain:$HOME/.local/share/flutter/bin:$PATH
flutter build linux --release

# 2. Prepare staging area
echo "Preparing Flatpak staging area..."
rm -rf $BUILD_DIR
mkdir -p $BUILD_DIR
cp -r build/linux/x64/release/bundle/* $BUILD_DIR/
cp $FLATPAK_DIR/${APP_ID}.json $BUILD_DIR/
cp $FLATPAK_DIR/${APP_ID}.desktop $BUILD_DIR/${APP_ID}.desktop
cp $FLATPAK_DIR/${APP_ID}.metainfo.xml $BUILD_DIR/${APP_ID}.metainfo.xml
cp $FLATPAK_DIR/icon.png $BUILD_DIR/

# 3. Build Flatpak
if ! command -v flatpak-builder &> /dev/null; then
    echo "Error: flatpak-builder not found. Please install it with: sudo apt install flatpak-builder"
    exit 1
fi

# Emergency bypass for Flathub 503: Check if required SDK is available locally
echo "Checking for Freedesktop SDK 24.08..."
SDK_PRESENT=false
if flatpak list --runtime | grep "org.freedesktop.Sdk" | grep -q "24.08"; then
    echo "SDK 24.08 found locally."
    SDK_PRESENT=true
fi

if [ "$SDK_PRESENT" = false ]; then
    echo "SDK 24.08 not found. Attempting to reach Flathub as last resort..."
    flatpak remote-add --user --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo || true
    flatpak update --user -y || echo "Warning: Could not update remotes, proceeding..."
fi

echo "Building Flatpak bundle..."
# Initialize local repo if not exists
if [ ! -d "repo" ]; then
    ostree init --mode=archive-z2 --repo=repo
fi

# Attempt build. If it fails specifically on AppStream, we will try again without it.
if [ "$SDK_PRESENT" = true ]; then
    flatpak-builder --force-clean --repo=repo build-dir $BUILD_DIR/${APP_ID}.json || \
    (echo "Warning: Build failed. Retrying without AppStream metadata..." && \
     sed -i '/metainfo.xml/d' $BUILD_DIR/${APP_ID}.json && \
     flatpak-builder --force-clean --repo=repo build-dir $BUILD_DIR/${APP_ID}.json)
else
    flatpak-builder --force-clean --repo=repo --install-deps-from=flathub build-dir $BUILD_DIR/${APP_ID}.json
fi

# Optional: Install locally for the user as well
echo "Installing locally for verification..."
flatpak-builder --user --install --force-clean build-dir $BUILD_DIR/${APP_ID}.json

echo "Exporting Flatpak bundle..."
flatpak build-bundle repo praxis.flatpak ${APP_ID}

echo "Success: prAxIs is now ready for Flatpak installation."
echo "-------------------------------------------------------"
echo "LOCAL INSTALL: Run 'flatpak-builder --user --install --force-clean build-dir $BUILD_DIR/${APP_ID}.json'"
echo "SHARING: Distribute 'praxis.flatpak' to other machines."
echo "REMOTE INSTALL: Run 'flatpak install --user praxis.flatpak' on the target machine."
echo "-------------------------------------------------------"
