#!/bin/bash

# ==============================================================================
# SCRIPT DE AUTOMACAO FLATHUB - V11 (FIX GITHUB SIZE LIMIT)
# ==============================================================================

set -e

# --- CONFIGURACOES ---
SOURCE_DIR=$(pwd)
SITE_DIR="$HOME/github/site"
FLATHUB_SUB_DIR="flathub-submission"
WORK_DIR="$SITE_DIR/$FLATHUB_SUB_DIR"

NEW_APP_ID="io.github.passosdomingues.praxis"
RUNTIME_VERSION="24.08" 
ARCHIVE_NAME="praxis-source.tar.gz"

# --- FUNCAO LOG ---
log_msg() { echo "[$(date '+%H:%M:%S')] $1"; }

log_msg "----------------------------------------------------------------"
log_msg "INICIANDO V11 - LIMPEZA DE ARQUIVOS GIGANTES"
log_msg "----------------------------------------------------------------"

if [ ! -d "$SITE_DIR" ]; then
    log_msg "ERRO: Diretorio site nao encontrado."
    exit 1
fi

# --- 1. RECUPERACAO DO REPOSITORIO (DESFAZER O COMMIT GIGANTE) ---
log_msg "Passo 1/7: Verificando estado do Git..."
cd "$SITE_DIR"

# Se o ultimo commit foi o gigante que falhou no push, vamos desfaze-lo
if git log -1 --pretty=%B | grep -q "Flathub Submission"; then
    log_msg "Detectado commit anterior falho. Desfazendo (git reset)..."
    git reset --soft HEAD~1
    git restore --staged .
    log_msg "Repositorio limpo do commit gigante."
fi

# Pega branch e URL
CURRENT_BRANCH=$(git branch --show-current)
[ -z "$CURRENT_BRANCH" ] && CURRENT_BRANCH="main"
# Converte para URL RAW para o manifesto
RAW_URL="https://raw.githubusercontent.com/passosdomingues/site/$CURRENT_BRANCH/$FLATHUB_SUB_DIR/$ARCHIVE_NAME"

# --- 2. CRIACAO DO PACOTE OTIMIZADO ---
log_msg "Passo 2/7: Criando pacote de codigo (SEM MODELOS DE IA)..."

rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"

cd "$SOURCE_DIR"

# AQUI ESTA A CORRECAO: Excluir tudo que for pesado
tar -czf "$WORK_DIR/$ARCHIVE_NAME" \
    --exclude='.git' \
    --exclude='build' \
    --exclude='build-dir' \
    --exclude='.flatpak-builder' \
    --exclude='*.flatpak' \
    --exclude='ollama*' \
    --exclude='*.tar' \
    --exclude='*.tar.*' \
    --exclude='*.zst' \
    --exclude='*.tgz' \
    --exclude='bin/ollama' \
    --exclude='ollama_bin' \
    .

# --- 3. VERIFICACAO DE TAMANHO ---
cd "$WORK_DIR"
FILE_SIZE_MB=$(du -m "$ARCHIVE_NAME" | cut -f1)
log_msg "Tamanho do arquivo gerado: ${FILE_SIZE_MB} MB"

if [ "$FILE_SIZE_MB" -gt 95 ]; then
    log_msg "ERRO FATAL: O arquivo ainda tem ${FILE_SIZE_MB}MB."
    log_msg "O GitHub bloqueia arquivos acima de 100MB."
    log_msg "Voce precisa remover mais binarios da pasta $SOURCE_DIR antes de continuar."
    exit 1
fi

SHA256=$(sha256sum "$ARCHIVE_NAME" | awk '{print $1}')
log_msg "Hash SHA256: $SHA256"

# --- 4. PREPARACAO DOS ARQUIVOS ---
log_msg "Passo 4/7: Copiando Assets..."
NEW_MANIFEST_PATH="$WORK_DIR/$NEW_APP_ID.yml"
cd "$SOURCE_DIR"

# Manifesto
OLD_MANIFEST=$(find . -maxdepth 1 -name "*.yml" | head -n 1)
cp "$OLD_MANIFEST" "$NEW_MANIFEST_PATH"

# Assets
ICON_SRC=$(find . -name "*.png" | grep -v "build/" | grep "512" | head -n 1)
[ -z "$ICON_SRC" ] && ICON_SRC=$(find flatpak -name "*.png" | head -n 1)
if [ -n "$ICON_SRC" ]; then cp "$ICON_SRC" "$WORK_DIR/$NEW_APP_ID.png"; fi

DESKTOP_SRC=$(find . -name "*.desktop" | grep -v "build/" | head -n 1)
if [ -n "$DESKTOP_SRC" ]; then cp "$DESKTOP_SRC" "$WORK_DIR/$NEW_APP_ID.desktop"; fi

XML_SRC=$(find . -name "*.metainfo.xml" -o -name "*.appdata.xml" | grep -v "build/" | head -n 1)
if [ -n "$XML_SRC" ]; then cp "$XML_SRC" "$WORK_DIR/$NEW_APP_ID.metainfo.xml"; fi

# --- 5. EDICAO DO MANIFESTO ---
log_msg "Passo 5/7: Configurando Manifesto..."
cd "$SITE_DIR"

OLD_ID_RAW=$(basename "$OLD_MANIFEST" .yml)

# IDs e Versao
sed -i "s/$OLD_ID_RAW/$NEW_APP_ID/g" "$NEW_MANIFEST_PATH"
sed -i "s/runtime-version: .*/runtime-version: '$RUNTIME_VERSION'/g" "$NEW_MANIFEST_PATH"

# Assets
sed -i "s/^Icon=.*/Icon=$NEW_APP_ID/" "$WORK_DIR/$NEW_APP_ID.desktop"
sed -i "s/$OLD_ID_RAW/$NEW_APP_ID/g" "$WORK_DIR/$NEW_APP_ID.desktop" 2>/dev/null || true
sed -i "s/$OLD_ID_RAW/$NEW_APP_ID/g" "$WORK_DIR/$NEW_APP_ID.metainfo.xml" 2>/dev/null || true

# Permissoes
sed -i "s/--filesystem=home/--filesystem=xdg-documents/g" "$NEW_MANIFEST_PATH"
sed -i "s/--filesystem=host//g" "$NEW_MANIFEST_PATH"
if ! grep -q -- "--share=ipc" "$NEW_MANIFEST_PATH"; then
    sed -i "/finish-args:/a \ \ - --share=ipc" "$NEW_MANIFEST_PATH"
fi

# Fonte (Archive)
sed -i "/type: dir/d" "$NEW_MANIFEST_PATH"
sed -i "/type: git/d" "$NEW_MANIFEST_PATH"
sed -i "/path: \./d" "$NEW_MANIFEST_PATH"
sed -i "/url: /d" "$NEW_MANIFEST_PATH"
sed -i "/branch: /d" "$NEW_MANIFEST_PATH"
sed -i "/commit: /d" "$NEW_MANIFEST_PATH"

# Injeta Archive Source
sed -i "s|sources:|sources:\n  - type: archive\n    url: $RAW_URL\n    sha256: $SHA256|" "$NEW_MANIFEST_PATH"

# --- 6. UPLOAD ---
log_msg "Passo 6/7: Enviando para o GitHub..."
cd "$SITE_DIR"
git add .

if git diff-index --quiet HEAD --; then
    log_msg "Nada novo para enviar."
else
    # Verifica se o arquivo gigante ainda esta no stage por algum motivo
    git rm --cached flathub-submission/praxis-source.tar.gz 2>/dev/null || true
    git add .
    
    git commit -m "Flathub Clean Submission ($NEW_APP_ID) - Small Archive"
    git push --set-upstream origin "$CURRENT_BRANCH"
    log_msg "Upload Concluido com Sucesso!"
fi

# --- 7. VALIDACAO ---
log_msg "Passo 7/7: Verificacao Final..."
cd "$WORK_DIR"
flatpak run --command=flatpak-builder-lint org.flatpak.Builder manifest "$NEW_APP_ID.yml" > linter_log.txt 2>&1 || true
cat linter_log.txt

log_msg "----------------------------------------------------------------"
log_msg "FIM DO PROCESSO"
log_msg "Manifesto e codigo fonte leve (<100MB) disponiveis em: $RAW_URL"
log_msg "----------------------------------------------------------------"
