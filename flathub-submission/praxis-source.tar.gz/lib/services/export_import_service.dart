import 'dart:convert';
import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'database_helper.dart';
import '../models/sprint.dart';
import '../models/task_card.dart';

class ExportImportService {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<File> exportData() async {
    // 1. Fetch all data
    final sprints = await _dbHelper.getAllSprints();
    final allCards = <TaskCard>[];
    for (final sprint in sprints) {
      if (sprint.id != null) {
        final cards = await _dbHelper.getCardsBySprint(sprint.id!);
        allCards.addAll(cards);
      }
    }

    // 2. Convert to JSON
    final data = {
      'version': 1,
      'timestamp': DateTime.now().toIso8601String(),
      'sprints': sprints.map((s) => s.toMap()).toList(),
      'cards': allCards.map((c) => c.toMap()).toList(),
    };

    final jsonString = jsonEncode(data);

    // 3. Create ZIP
    final archive = Archive();
    final settings = ZipEncoder();
    archive.addFile(ArchiveFile('scrum_data.json', jsonString.length, jsonString.codeUnits));
    
    final zipData = settings.encode(archive);
    
    final tempDir = await getTemporaryDirectory();
    final zipFile = File(p.join(tempDir.path, 'scrum_backup_${DateTime.now().millisecondsSinceEpoch}.zip'));
    await zipFile.writeAsBytes(zipData!);
    
    return zipFile;
  }

  Future<void> importData(File zipFile) async {
    final bytes = await zipFile.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    
    final jsonFile = archive.findFile('scrum_data.json');
    if (jsonFile == null) {
      throw Exception('Invalid backup file');
    }

    final jsonString = String.fromCharCodes(jsonFile.content);
    final data = jsonDecode(jsonString);

    // 4. Restore Data (Transactional? For now, simple wipe and replace)
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      // Wipe
      await txn.delete('cards');
      await txn.delete('sprints');

      // Restore Sprints and keep mapping old ID to new ID if needed (or just force ID)
      // Since we use AutoIncrement, trying to force ID might work if not taken.
      // But safest is to strip IDs and re-insert, but that breaks relationships.
      // So we will try to INSERT with specific IDs.
      
      for (final sMap in data['sprints']) {
        await txn.insert('sprints', sMap);
      }
      
      for (final cMap in data['cards']) {
        await txn.insert('cards', cMap);
      }
    });
  }
}
