import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/sprint.dart';
import '../../services/app_provider.dart';

class BurndownChart extends StatelessWidget {
  const BurndownChart({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final sprint = provider.activeSprint;
    final cards = provider.cards;

    if (sprint == null) {
      return const Center(child: Text("No Active Sprint"));
    }

    // Calculate Data
    final totalPoints = cards.fold<int>(0, (sum, c) => sum + c.points);
    final duration = sprint.endDate.difference(sprint.startDate).inDays + 1;
    
    // Ideal Line
    final idealSpots = [
      FlSpot(0, totalPoints.toDouble()),
      FlSpot(duration.toDouble(), 0),
    ];

    // Actual Line (Simplified: Current Pending Points)
    // To do a real historical burndown, we'd need a history table.
    // For this MVP, we will just show the current state as the "latest point"
    // and assume linear progress for previous days (fake it) or just show current day drop.
    // Let's show: Day 0 = Total, Current Day = Current Pending.
    // Linear interpolation in between is misleading.
    // Better: Just show the current status point.
    
    final completedPoints = cards.where((c) => c.columnId == 3).fold<int>(0, (sum, c) => sum + c.points);
    final pendingPoints = totalPoints - completedPoints;
    
    final daysElapsed = DateTime.now().difference(sprint.startDate).inDays;
    final validDay = daysElapsed.clamp(0, duration);
    
    final actualSpots = [
      FlSpot(0, totalPoints.toDouble()),
      FlSpot(validDay.toDouble(), pendingPoints.toDouble()),
    ];

    final theme = Theme.of(context);
    final primaryColor = theme.colorScheme.primary;
    final secondaryColor = theme.colorScheme.secondary;

    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: LineChart(
        LineChartData(
          gridData: FlGridData(
            show: true, 
            drawVerticalLine: true,
            getDrawingHorizontalLine: (value) => FlLine(color: Colors.white10, strokeWidth: 1),
            getDrawingVerticalLine: (value) => FlLine(color: Colors.white10, strokeWidth: 1),
          ),
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true, 
                reservedSize: 40,
                getTitlesWidget: (value, meta) => Text(value.toInt().toString(), style: const TextStyle(color: Colors.white54, fontSize: 10)),
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true, 
                interval: 1,
                getTitlesWidget: (value, meta) => Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text('Day ${value.toInt()}', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                ),
              ),
            ),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          borderData: FlBorderData(show: true, border: Border.all(color: Colors.white10)),
          minX: 0,
          maxX: duration.toDouble(),
          minY: 0,
          maxY: (totalPoints + 5).toDouble(), // Buffer
          lineBarsData: [
            // Ideal
            LineChartBarData(
              spots: idealSpots,
              isCurved: false,
              color: Colors.white24,
              barWidth: 2,
              dotData: const FlDotData(show: false),
              dashArray: [5, 5],
            ),
            // Actual
            LineChartBarData(
              spots: actualSpots,
              isCurved: true,
              color: primaryColor,
              barWidth: 5,
              isStrokeCapRound: true,
              dotData: FlDotData(
                show: true, 
                getDotPainter: (spot, percent, barData, index) => FlDotCirclePainter(
                  radius: 5, 
                  color: secondaryColor, 
                  strokeWidth: 2, 
                  strokeColor: Colors.white,
                ),
              ),
              belowBarData: BarAreaData(
                show: true, 
                gradient: LinearGradient(
                  colors: [
                    primaryColor.withOpacity(0.3),
                    primaryColor.withOpacity(0.0),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
